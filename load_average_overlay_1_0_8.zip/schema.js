"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverDataSchema = exports.camOverlaySchema = exports.cloudSchema = exports.connectionParamsSchema = void 0;
const zod_1 = require("zod");
exports.connectionParamsSchema = zod_1.z.object({
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
    port: zod_1.z.number().positive().lt(65535),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
});
exports.cloudSchema = zod_1.z.object({
    use_cloud: zod_1.z.boolean(),
    cloud_url: zod_1.z.string(),
    device_access_token: zod_1.z.string(),
});
exports.camOverlaySchema = zod_1.z.object({
    service_id: zod_1.z.number().int().nonnegative(),
    mode: zod_1.z.union([zod_1.z.literal('separate'), zod_1.z.literal('combined'), zod_1.z.literal('both')]),
    show_load1: zod_1.z.boolean(),
    show_load5: zod_1.z.boolean(),
    show_load15: zod_1.z.boolean(),
    field_load1: zod_1.z.string(),
    field_load5: zod_1.z.string(),
    field_load15: zod_1.z.string(),
    field_combined: zod_1.z.string(),
    combined_format: zod_1.z.string(),
});
exports.serverDataSchema = zod_1.z.object({
    output_camera: exports.connectionParamsSchema,
    cloud: exports.cloudSchema,
    camoverlay: exports.camOverlaySchema,
    update_interval_ms: zod_1.z.number().int().positive(),
});
