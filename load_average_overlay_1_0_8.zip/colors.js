"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOAD_THRESHOLD_RED = exports.LOAD_THRESHOLD_ORANGE = void 0;
exports.rgbToParam = rgbToParam;
exports.colorForLoad = colorForLoad;
// Load-average severity colors for CamOverlay Custom Graphics fields.
// Thresholds: green below 2, orange from 2 up to 3, red above 3.
exports.LOAD_THRESHOLD_ORANGE = 2;
exports.LOAD_THRESHOLD_RED = 3;
const GREEN = [0, 200, 0];
const ORANGE = [255, 165, 0];
const RED = [255, 0, 0];
function pad3(n) {
    return Math.max(0, Math.min(255, Math.round(n))).toString().padStart(3, '0');
}
// CamOverlay's customGraphics.cgi color params take a 9-digit RRRGGGBBB string
// (each channel zero-padded to 3 digits, e.g. white = 255255255).
function rgbToParam([r, g, b]) {
    return pad3(r) + pad3(g) + pad3(b);
}
function colorForLoad(value) {
    const n = parseFloat(value);
    if (!Number.isFinite(n) || n < exports.LOAD_THRESHOLD_ORANGE) {
        return rgbToParam(GREEN);
    }
    if (n <= exports.LOAD_THRESHOLD_RED) {
        return rgbToParam(ORANGE);
    }
    return rgbToParam(RED);
}
